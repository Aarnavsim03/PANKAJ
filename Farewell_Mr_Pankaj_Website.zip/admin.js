
function loginAdmin() {
  const password = document.getElementById("adminPassword").value;
  if (password === "Pankajsir01") {
    document.getElementById("adminPanel").style.display = "block";
    alert("Admin logged in! (In real app, data would load from Firebase)");
  } else {
    alert("Incorrect password!");
  }
}
