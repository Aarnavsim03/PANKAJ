
function toggleMusic() {
  const music = document.getElementById("bgMusic");
  music.hidden = !music.hidden;
  if (music.hidden) {
    music.pause();
  } else {
    music.play();
  }
}
document.getElementById("messageForm").addEventListener("submit", (e) => {
  e.preventDefault();
  alert("Message submitted! (In real app, this would go to Firebase)");
});
